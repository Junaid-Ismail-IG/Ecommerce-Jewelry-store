<?php
include('includes/dbconfig.php');
   

if (!$connect) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $customer_id = $_GET['id'];

    $deleteQuery = "DELETE FROM customers_detail WHERE customer_id = $customer_id";
    $deleteResult = mysqli_query($connect, $deleteQuery);

    if ($deleteResult) {
        // Redirect to the customer details page after deleting
        header("Location: orders.php");
        exit;
    } else {
        echo "Error deleting customer.";
        exit;
    }
} else {
    echo "Invalid customer ID.";
    exit;
}
?>
