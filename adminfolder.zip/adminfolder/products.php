<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <!-- Boxicons CSS -->
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-modal/2.2.6/js/bootstrap-modalmanager.min.js" integrity="sha512-/HL24m2nmyI2+ccX+dSHphAHqLw60Oj5sK8jf59VWtFWZi9vx7jzoxbZmcBeeTeCUc7z1mTs3LfyXGuBU32t+w==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <title>Dashboard</title>
    <link rel="stylesheet" href="style.css" />
  </head><style>
  .suggestion {
    cursor: pointer;
  }
  
</style>
  <body style="background-color: whitesmoke;">
    <!-- navbar -->
    <nav class="navbar">
      <div class="logo_item">
        <i class="bx bx-menu" id="sidebarOpen"></i>
        <img src="productimages/blank-profile-picture-image-holder-with-a-crown-vector-42411540.jpg" alt=""></i>Admin Panel
      </div>


      <div class="navbar_content">
        <i class="bi bi-grid"></i>
        <a href="logout.php"><i class='bx bx-log-out' ></i></a>
      </div>
    </nav>
<div class="cont">
    <!-- sidebar -->
    <nav class="sidebar">
      <div class="menu_content">
        <ul class="menu_items" style="padding-top: 40px;">
          <!-- duplicate or remove this li tag if you want to add or remove navlink with submenu -->
          <!-- start -->
          <li class="item">
          <a href="dashboard.php" class="items" style="text-decoration: none;">
            <div  class="nav_link submenu_item">
              <span class="navlink_icon">
                <i class="bx bx-home-alt"></i>
              </span>
              <span class="navlink">Home</span>
            </div>
          </a>
          </li>
          <!-- end -->

          <!-- duplicate this li tag if you want to add or remove  navlink with submenu -->
          <!-- start -->
          <li class="item">
          <a href="products.php" class="items" style="text-decoration: none;">
            <div  class="nav_link submenu_item">
              <span class="navlink_icon">
                <i class="bx bx-cart-alt"></i>
              </span>
              <span class="navlink">Products</span>
            </div>
          </a> 
          </li>
          <!-- end -->
          <li class="item">
          <a href="orders.php" class="items"  style="text-decoration: none;">
            <div class="nav_link submenu_item">
              <span class="navlink_icon">
                <i class="bx bx-notepad"></i>
              </span>
              <span class="navlink">Orders</span>
            </div>
          </a>
          </li>
   
        <!-- end -->
        <li class="item">
            <a href="customers.php" class="items" style="text-decoration: none;">
            <div  class="nav_link submenu_item">
              <span class="navlink_icon">
                <i class="bx bx-user"></i>
              </span>
              <span class="navlink">customers</span>
            </div>
            </a>
          </li>
        </ul>


        <!-- Sidebar Open / Close -->
        <div class="bottom_content">
          <div class="bottom expand_sidebar">
            <span> Expand</span>
            <i class='bx bx-arrow-to-right' ></i>
          </div>
          <div class="bottom collapse_sidebar">
            <span> Collapse</span>
            <i class='bx bx-collapse-horizontal'></i>
          </div>
        </div>
      </div>
    </nav>


    <div class="modal fade" id="insertdata" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add New Product</h5>
        <button type="button" class="btn-close text-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="productcode.php" method="POST" class="col-lg-6 col-md-6" enctype="multipart/form-data">
          <div class="mb-3">
            <label for="product_image" class="form-label" >Product Image:</label>
            <input type="file" name="image" class="form-control">
          </div>
          <div class="mb-3">
            <label for="product_name" class="form-label">Product Name:</label>
            <input type="text" placeholder="Product Name" name="product_name" class="form-control">
          </div>
          <div class="mb-3">
            <label for="price" class="form-label">Price:</label>
            <input type="number" placeholder="Price" name="price" class="form-control">
          </div>
          <div class="mb-3">
            <label for="product_category" class="form-label">Product Category:</label>
            <select class="form-select" name="product_category" id="product_category">
              <option value="jewelry">Jewelry</option>
              <option value="Cosmetic">Cosmetic</option>
            </select>
          </div>
          <div class="mb-3">
           <label for="product_description">Product Description:</label>
            <textarea name="product_description" id="product_description" rows="6" cols="50"></textarea>
          </div>
          <button type="submit" name="add_product" class="btn btn-danger">Add Product</button>
        </form>
        <br>
        <br>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

    <!-- Products -->

    <div class="card" style="margin: 100px;justify-content:center;">
  <div class="card-header">
    <h1 style="color:#922022;">Products</h1>
  <!-- Add this code where you want the search bar -->
<div class="input-group mb-3">
  <input type="text" class="form-control" placeholder="Search products" id="searchInput">
  <button class="btn btn-outline-secondary" type="button" id="searchButton">
    <i class='bx bx-search'></i> Search
  </button>
</div>

<!-- Suggestions container -->
<div id="suggestionsContainer" class="mb-3"></div>


    <button type="button" class="btn btn-danger float-end" data-bs-toggle="modal" data-bs-target="#insertdata">
 Add Product  <i class='bx bx-plus'></i>
</button>
  </div>
  <br>



<div class="table-responsive">
  <table class="table table-striped table-bordered table-hover" border="1" style="text-align: center;">
    <thead>
        <th>Product Id</th>
        <th>Product Name</th>
        <th>Product Category</th>
        <th>Products Details</th>
        <th>Delete Product</th>
    </thead>

    <tbody class="displayrows">
    <?php
              include('includes/dbconfig.php');
   
                $productsquery = "SELECT * FROM products";
                $result = mysqli_query($connect, $productsquery);

                if ($result) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        ?><!-- Inside the tbody loop -->
                        <tr class="displayrow">
                          <td><?php echo $row['product_id'];?></td>
                          <td><?php echo $row['product_name']; ?></td>
                          <td><?php echo $row['product_category']; ?></td>
                          <td>
                            <button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#productDetailsModal<?php echo $row['product_id']; ?>"><i class='bx bx-info-circle'></i> Details</button>              
                          </td>
                          <td>
                          <a href="productcode.php?id=<?php echo $row['product_id']; ?>&deleteproduct" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this product?')"><i class='bx bx-trash'></i> Delete</a>
                          </td>
                        </tr>
                        
                        <!-- Product Details Modal -->
                        <div class="modal fade" id="productDetailsModal<?php echo $row['product_id']; ?>" tabindex="-1" aria-labelledby="productDetailsModalLabel<?php echo $row['product_id']; ?>" aria-hidden="true">
                          <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h5 class="modal-title" id="productDetailsModalLabel<?php echo $row['product_id']; ?>">Product Details</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                              </div>
                              <div class="modal-body">
                                <img src="productimages/<?php echo $row['image_url'];?>" alt="" class="img-fluid"  style="max-width: 100%; height: 300px;">
                                <p><strong>Name: </strong> <?php echo $row['product_name']; ?></p>
                                <p><strong>Price: </strong> <?php echo $row['price']; ?></p>
                                <p><strong>Category: </strong> <?php echo $row['product_category']; ?></p>
                                <p><strong>Description: </strong> <?php echo $row['product_description']; ?></p>
                                <!-- Add more details as needed -->
                              </div>
                              <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                              </div>
                            </div>
                          </div>
                        </div>
                        


    </tbody>
    <?php
                    }
                }
                ?>
  </table>
  </div>
  </div>
</div>
</div><script>
  document.getElementById('searchInput').addEventListener('input', function() {
    var searchInput = this.value.toUpperCase();
    var displayRows = document.getElementsByClassName('displayrow');
    var suggestionsContainer = document.getElementById('suggestionsContainer');

    // Clear previous suggestions
    suggestionsContainer.innerHTML = '';

    for (var i = 0; i < displayRows.length; i++) {
      var productName = displayRows[i].getElementsByTagName('td')[1].textContent.toUpperCase();
      if (productName.indexOf(searchInput) > -1) {
        // Create a suggestion element
        var suggestion = document.createElement('div');
        suggestion.className = 'suggestion';
        suggestion.innerHTML = productName;

        // Add a click event to the suggestion
        suggestion.addEventListener('click', function() {
          // Show only the clicked product and hide others
          var clickedProductName = this.innerHTML.toUpperCase();
          for (var j = 0; j < displayRows.length; j++) {
            var rowProductName = displayRows[j].getElementsByTagName('td')[1].textContent.toUpperCase();
            if (rowProductName === clickedProductName) {
              displayRows[j].style.display = '';
            } else {
              displayRows[j].style.display = 'none';
            }
          }
          
          // Clear suggestions after clicking
          suggestionsContainer.innerHTML = '';
        });

        // Append the suggestion to the container
        suggestionsContainer.appendChild(suggestion);
      }
    }
  });
</script>

    <!-- JavaScript -->
    <script src="script.js"></script>
  </body>
</html>