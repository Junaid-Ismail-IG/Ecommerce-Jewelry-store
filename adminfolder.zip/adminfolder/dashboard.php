
<!DOCTYPE html>
<html lang="en">
  <head>
    <style>
      .container{
        display: flex;
        justify-content: space-around;
        flex-wrap: wrap;
      }
      h2 , h4{
        color: #922022 !important;
        text-shadow: #EEEEEE 1px 1px 2px;
      }
      .card{
        background-color: #F8FAE5 !important;
      }
      .card-header{
        background-color: #EEF0E5 !important;
      }
    </style>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <!-- Boxicons CSS -->
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-modal/2.2.6/js/bootstrap-modalmanager.min.js" integrity="sha512-/HL24m2nmyI2+ccX+dSHphAHqLw60Oj5sK8jf59VWtFWZi9vx7jzoxbZmcBeeTeCUc7z1mTs3LfyXGuBU32t+w==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
   
    <title>Dashboard</title>
    <link rel="stylesheet" href="style.css" />
  </head>
  <body style="background-color: #EEEEEE;">
    <!-- navbar -->
    <nav class="navbar">
      <div class="logo_item">
        <i class="bx bx-menu" id="sidebarOpen"></i>
        <img src="productimages/blank-profile-picture-image-holder-with-a-crown-vector-42411540.jpg" alt=""></i>Admin Panel
      </div>


      <div class="navbar_content">
        <i class="bi bi-grid"></i>
        <a href="logout.php">
        <i class='bx bx-log-out'></i>
        </a>
      </div>
    </nav>

    <!-- sidebar -->
    <nav class="sidebar">
      <div class="menu_content">
        <ul class="menu_items" style="padding-top: 40px;">
          <!-- duplicate or remove this li tag if you want to add or remove navlink with submenu -->
          <!-- start -->
          <li class="item">
          <a href="dashboard.php" class="items" style="text-decoration: none;">
            <div  class="nav_link submenu_item">
              <span class="navlink_icon">
                <i class="bx bx-home-alt"></i>
              </span>
              <span class="navlink">Home</span>
            </div>
          </a>
          </li>
          <!-- end -->

          <!-- duplicate this li tag if you want to add or remove  navlink with submenu -->
          <!-- start -->
          <li class="item">
          <a href="products.php" class="items" style="text-decoration: none;">
            <div  class="nav_link submenu_item">
              <span class="navlink_icon">
                <i class="bx bx-cart-alt"></i>
              </span>
              <span class="navlink">Products</span>
            </div>
          </a> 
          </li>
          <!-- end -->
          <li class="item">
          <a href="orders.php" class="items"  style="text-decoration: none;">
            <div class="nav_link submenu_item">
              <span class="navlink_icon">
                <i class="bx bx-notepad"></i>
              </span>
              <span class="navlink">Orders</span>
            </div>
          </a>
          </li>
   
        <!-- end -->
        <li class="item">
            <a href="customers.php" class="items" style="text-decoration: none;">
            <div  class="nav_link submenu_item">
              <span class="navlink_icon">
                <i class="bx bx-user"></i>
              </span>
              <span class="navlink">customers</span>
            </div>
            </a>
          </li>
        </ul>


        <!-- Sidebar Open / Close -->
        <div class="bottom_content">
          <div class="bottom expand_sidebar">
            <span> Expand</span>
            <i class='bx bx-arrow-to-right' ></i>
          </div>
          <div class="bottom collapse_sidebar">
            <span> Collapse</span>
          </div>
        </div>
      </div>
    </nav>
    
    <div class="container">
    <div class="card" style="margin-top: 100px;width:270px;">
  <div class="card-header">
  
    <h3>Total Products</h3>
  </div>
  <div class="card-body" style="padding:30px;">
    <h5 class="card-title">Cosmetics</h5>
    <h2>
    <?php
    include('includes/dbconfig.php');
   
    $c_category = "Cosmetic";
    $c_query = "SELECT * FROM products WHERE product_category= '$c_category' ";
    $c_query_run = mysqli_query($connect , $c_query);
    $c_total=mysqli_num_rows($c_query_run);
    if($c_total){
      echo  $c_total ;
    }
    else{
      echo"Null";
    }
    ?>
    </h2>
    <br><hr><br> 
    <h5 class="card-title">Jewellery</h5>
    <h2>
    <?php
    $j_category = "jewelry";
    $j_query = "SELECT * FROM products WHERE product_category= '$j_category' ";
    $j_query_run = mysqli_query($connect , $j_query);
    $j_total = mysqli_num_rows($j_query_run);
    if($j_total){
      echo  $j_total ;
    }
    else{
      echo"Null";
    }
    ?>
    </h2>
    <hr>
  <a href="products.php" style="text-decoration: none;color:#922022;">view details   <i class="bx bx-link-external"></i></a>
  
  </div>
  
</div>

<div class="card" style="margin-top: 100px;width:270px;text-align:center;">
  <div class="card-header">
    <h3>Total Orders</h3>
  </div>
  <div class="card-body" style="padding:30px;">
    <h2 class="card-title" style="color: black!important;">orders</h5>
    <h2 style="color:#922022;">
    <?php
    $o_query = "SELECT * FROM orders";
    $o_query_run = mysqli_query($connect , $o_query);
    $o_total=mysqli_num_rows($o_query_run);
    if($o_total){
      echo  $o_total ;
    }
    else{
      echo"Null";
    }
    ?>
    </h2><hr>
    <a href="orders.php" style="text-decoration: none;color:#922022;">view details   <i class="bx bx-link-external"></i></a>
  </div>
</div>


<div class="card" style="margin-top:100px;width:270px;text-align:center;height:auto;">
  <div class="card-header">
    <h3>Total Customers</h3>
  </div>
  <div class="card-body" style="padding:30px;">
    <h2 class="card-title" style="color: black!important;">Customers</h5>
    <h2 style="color:#922022;">
    <?php
    $cs_query = "SELECT * FROM customers";
    $cs_query_run = mysqli_query($connect , $cs_query);
    $cs_total=mysqli_num_rows($cs_query_run);
    if($cs_total){
      echo  $cs_total ;
    }
    else{
      echo"Null";
    }
    ?>
    </h2><hr>
    <a href="customers.php" style="text-decoration: none;color:#922022;">view details   <i class="bx bx-link-external"></i></a>
  </div>
</div>

    </div>
    <!-- JavaScript -->
    <script src="script.js"></script>
  </body>
</html>