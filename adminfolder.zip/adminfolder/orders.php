<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <!-- Boxicons CSS -->
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-modal/2.2.6/js/bootstrap-modalmanager.min.js" integrity="sha512-/HL24m2nmyI2+ccX+dSHphAHqLw60Oj5sK8jf59VWtFWZi9vx7jzoxbZmcBeeTeCUc7z1mTs3LfyXGuBU32t+w==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  
    <title>Dashboard</title>
    <link rel="stylesheet" href="style.css" />
  </head>
  <body>
    <!-- navbar -->
    <nav class="navbar">
      <div class="logo_item">
        <i class="bx bx-menu" id="sidebarOpen"></i>
        <img src="productimages/blank-profile-picture-image-holder-with-a-crown-vector-42411540.jpg" alt=""></i>Admin Panel
      </div>


      <div class="navbar_content">
        <i class="bi bi-grid"></i>
        <a href="logout.php"><i class='bx bx-log-out' ></i></a>
      </div>
    </nav>

    <!-- sidebar -->
    <nav class="sidebar">
      <div class="menu_content">
        <ul class="menu_items" style="padding-top: 40px;">
          <!-- duplicate or remove this li tag if you want to add or remove navlink with submenu -->
          <!-- start -->
          <li class="item">
          <a href="dashboard.php" class="items" style="text-decoration: none;">
            <div  class="nav_link submenu_item">
              <span class="navlink_icon">
                <i class="bx bx-home-alt"></i>
              </span>
              <span class="navlink">Home</span>
            </div>
          </a>
          </li>
          <!-- end -->

          <!-- duplicate this li tag if you want to add or remove  navlink with submenu -->
          <!-- start -->
          <li class="item">
          <a href="products.php" class="items" style="text-decoration: none;">
            <div  class="nav_link submenu_item">
              <span class="navlink_icon">
                <i class="bx bx-cart-alt"></i>
              </span>
              <span class="navlink">Products</span>
            </div>
          </a> 
          </li>
          <!-- end -->
          <li class="item">
          <a href="orders.php" class="items"  style="text-decoration: none;">
            <div class="nav_link submenu_item">
              <span class="navlink_icon">
                <i class="bx bx-notepad"></i>
              </span>
              <span class="navlink">Orders</span>
            </div>
          </a>
          </li>
   
        <!-- end -->
        <li class="item">
            <a href="customers.php" class="items" style="text-decoration: none;">
            <div  class="nav_link submenu_item">
              <span class="navlink_icon">
                <i class="bx bx-user"></i>
              </span>
              <span class="navlink">customers</span>
            </div>
            </a>
          </li>
        </ul>


        <!-- Sidebar Open / Close -->
        <div class="bottom_content">
          <div class="bottom expand_sidebar">
            <span> Expand</span>
            <i class='bx bx-arrow-to-right' ></i>
          </div>
          <div class="bottom collapse_sidebar">
            <span> Collapse</span>
          </div>
        </div>
      </div>
    </nav>
    <?php
// Fetch order item details
include('includes/dbconfig.php');
   
$orderItemQuery = "SELECT oi.order_item_id, oi.order_id, oi.product_id, oi.quantity, oi.price, p.image_url, c.first_name, c.last_name, o.customer_id
                     FROM order_items oi
                     JOIN products p ON oi.product_id = p.product_id
                     JOIN orders o ON oi.order_id = o.order_id
                     JOIN customers_detail c ON o.customer_id = c.customer_id";
$orderItemResult = mysqli_query($connect, $orderItemQuery);
?>



<div class="card" style="margin: 100px;">
    <div class="card-header">
        <h2 style="color: #922022;">Order Items</h2>
    </div>
    <div class="card-body">

        <div class="table-responsive">
        <table class="table table-bordered" border="1" style="text-align: center;">
                    <thead class="bg-light">
                        <th>Order Item ID</th>
                        <th>Order ID</th>
                        <th>Customer Name</th>
                        <th>Product ID</th>
                        <th>Product Image</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Detail</th>
                    </thead>
                    <tbody>
                        <?php
                        if ($orderItemResult) {
                            while ($row = mysqli_fetch_assoc($orderItemResult)) {
                                ?>
                               <tr>
    <td><?php echo $row['order_item_id']; ?></td>
    <td><?php echo $row['order_id']; ?></td>
    <td><?php echo $row['first_name'] . ' ' . $row['last_name']; ?></td>
    <td><?php echo $row['product_id']; ?></td>
    <td><img src="productimages/<?php echo $row['image_url']; ?>" alt="Product Image" style="width: 50px; height: 50px;"></td>
    <td><?php echo $row['quantity']; ?></td>
    <td><?php echo $row['price']; ?></td>
    <!-- Update this part inside the loop where you generate table rows -->
    <td>
        <button type="button" class="btn btn-secondary btn-detail-order" data-bs-toggle="modal" data-bs-target="#orderDetailsModal<?php echo $row['order_id']; ?>" data-product-id="<?php echo $row['product_id']; ?>"><i class='bx bx-info-circle'></i> Order Details</button>
    </td>
</tr>

                                
 <!-- orders Details Modal -->
 <!-- Update this part of the modal -->
<div class="modal fade" id="orderDetailsModal<?php echo $row['order_id']; ?>" tabindex="-1" aria-labelledby="orderDetailsModalLabel<?php echo $row['order_id']; ?>" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="orderDetailsModalLabel<?php echo $row['order_id']; ?>">Order Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <h3>Product Details</h3><br>
                <img src="productimages/<?php echo $row['image_url'];?>" alt="" class="img-fluid" style="max-width: 100%; height: 100px;">
                <p><strong>Product ID: </strong> <?php echo $row['product_id']; ?></p>
                <p><strong>Price: </strong> <?php echo $row['price']; ?></p>
                <!-- Add more details as needed -->

                <?php
                // You can use the product_id to fetch additional details from the database
                $productId = $row['product_id'];
                $productDetailsQuery = "SELECT * FROM products WHERE product_id = $productId";
                $productDetailsResult = mysqli_query($connect, $productDetailsQuery);

                if ($productDetailsResult) {
                    $productDetails = mysqli_fetch_assoc($productDetailsResult);
                    ?>
                    <p><strong>Product Name</strong> <?php echo $productDetails['product_name']; ?></p>
                    <?php
                } else {
                    echo "No additional details found";
                }
                ?>
              <br>
                <?php
             
$productId = $row['product_id'];
$oQuery = "SELECT quantity FROM order_items WHERE product_id = $productId";
$oResult = mysqli_query($connect, $oQuery);

if ($oResult) {
    $o = mysqli_fetch_assoc($oResult);
    ?>
    <p><strong>Quantity Ordered: </strong> <?php echo $o['quantity']; ?></p>
    <?php
                $customerId = $row['customer_id'];
                $cQuery = "SELECT * FROM orders WHERE customer_id = $customerId";
                $cResult = mysqli_query($connect, $cQuery);

                if ($cResult) {
                    $c = mysqli_fetch_assoc($cResult);
                    ?>
                    <p><strong>Total Amount: </strong> <?php echo $o['quantity']*$row['price'] ?>/.</p>
                    <p><strong>Payment Method: </strong> <?php echo $c['payment_method']; ?></p>
                    <?php
                } else {
                    echo "No details found";
                }?>
    <?php
} else {
    echo "No details found";
}

if (!$oResult) {
    die("Query failed: " . mysqli_error($connect));
}
              ?>


              <hr>
              <h3>Customer Details - Shipping Address</h3><br>
              <?php
                // Fetch customer details based on the order
                $customerId = $row['customer_id'];
                $customerDetailsQuery = "SELECT * FROM customers_detail WHERE customer_id = $customerId";
                $customerDetailsResult = mysqli_query($connect, $customerDetailsQuery);

                if ($customerDetailsResult) {
                    $customerDetails = mysqli_fetch_assoc($customerDetailsResult);
                    ?>
                    <p><strong>Customer Name:</strong> <?php echo $customerDetails['first_name'] . ' ' . $customerDetails['last_name']; ?></p>
                    <p><strong>Email:</strong> <?php echo $customerDetails['email']; ?></p>
                    <p><strong>Country:</strong> <?php echo $customerDetails['country']; ?></p>
                    <p><strong>Sreet Address:</strong> <?php echo $customerDetails['street_address']; ?></p>
                    <p><strong>Town:</strong> <?php echo $customerDetails['town']; ?></p>
                    <p><strong>State:</strong> <?php echo $customerDetails['state']; ?></p>
                    <p><strong>PostCode:</strong> <?php echo $customerDetails['postcode']; ?></p>
                    <p><strong>Phone:</strong> <?php echo $customerDetails['phone']; ?></p>
                    <p><strong>order date and time:</strong> <?php echo $customerDetails['created_at']; ?></p>
                    <!-- ... (other customer details) ... -->
                    <?php
                } else {
                    echo "No customer details found";
                }
                ?>
                <hr>
                <br>
               
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

                                <?php
                            }
                        } else {
                            echo "No order item details found";
                        }
                        ?>
                    </tbody>
                </table>
        </div>
    </div>
</div>
    
    <!-- JavaScript -->
    <script src="script.js"></script>
  </body>
</html>