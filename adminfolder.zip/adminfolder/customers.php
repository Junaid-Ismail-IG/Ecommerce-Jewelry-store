<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <!-- Boxicons CSS -->
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-modal/2.2.6/js/bootstrap-modalmanager.min.js" integrity="sha512-/HL24m2nmyI2+ccX+dSHphAHqLw60Oj5sK8jf59VWtFWZi9vx7jzoxbZmcBeeTeCUc7z1mTs3LfyXGuBU32t+w==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  
    <title>Dashboard</title>
    <link rel="stylesheet" href="style.css" />
  </head>
  <body>
    <!-- navbar -->
    <nav class="navbar">
      <div class="logo_item">
        <i class="bx bx-menu" id="sidebarOpen"></i>
        <img src="productimages/blank-profile-picture-image-holder-with-a-crown-vector-42411540.jpg" alt=""></i>Admin Panel
      </div>


      <div class="navbar_content">
        <i class="bi bi-grid"></i>

        <a href="logout.php"><i class='bx bx-log-out' ></i></a>
      </div>
    </nav>

    <!-- sidebar -->
    <nav class="sidebar">
      <div class="menu_content">
        <ul class="menu_items" style="padding-top: 40px;">
          <!-- duplicate or remove this li tag if you want to add or remove navlink with submenu -->
          <!-- start -->
          <li class="item">
          <a href="dashboard.php" class="items" style="text-decoration: none;">
            <div  class="nav_link submenu_item">
              <span class="navlink_icon">
                <i class="bx bx-home-alt"></i>
              </span>
              <span class="navlink">Home</span>
            </div>
          </a>
          </li>
          <!-- end -->

          <!-- duplicate this li tag if you want to add or remove  navlink with submenu -->
          <!-- start -->
          <li class="item">
          <a href="products.php" class="items" style="text-decoration: none;">
            <div  class="nav_link submenu_item">
              <span class="navlink_icon">
                <i class="bx bx-cart-alt"></i>
              </span>
              <span class="navlink">Products</span>
            </div>
          </a> 
          </li>
          <!-- end -->
          <li class="item">
          <a href="orders.php" class="items"  style="text-decoration: none;">
            <div class="nav_link submenu_item">
              <span class="navlink_icon">
                <i class="bx bx-notepad"></i>
              </span>
              <span class="navlink">Orders</span>
            </div>
          </a>
          </li>
   
        <!-- end -->
        <li class="item">
            <a href="customers.php" class="items" style="text-decoration: none;">
            <div  class="nav_link submenu_item">
              <span class="navlink_icon">
                <i class="bx bx-user"></i>
              </span>
              <span class="navlink">customers</span>
            </div>

            </a>
          </li>
        </ul>


        <!-- Sidebar Open / Close -->
        <div class="bottom_content">
          <div class="bottom expand_sidebar">
            <span> Expand</span>
            <i class='bx bx-arrow-to-right' ></i>
          </div>
          <div class="bottom collapse_sidebar">
            <span> Collapse</span>
            <i class='bx bx-collapse-horizontal'></i>
          </div>
        </div>
      </div>
    </nav>
<!-- Bootstrap card to display customer information -->
<div class="card" style="margin: 100px;">
          <div class="card-header">
            <h5 class="card-title">Customer Records</h5>
            <div class="input-group mb-3">
  <input type="text" class="form-control" placeholder="Search products" id="searchInput">
  <button class="btn btn-outline-secondary" type="button" id="searchButton">
    <i class='bx bx-search'></i> Search
  </button>
</div>
            </div>
            <br>
            <div class="card-body">
  <?php
include('includes/dbconfig.php');
   
    // Check connection
    if (!$connect) {
      die("Connection failed: ");
    }

    // SQL query to fetch customer records
    $sql = "SELECT customer_id, customer_name, customer_email, customer_timestamp FROM customers";
    $result = $connect->query($sql);

    // Check if there are any records
    if ($result->num_rows > 0) {
      // Output data of each row
      while($row = $result->fetch_assoc()) {
  ?>
        
            <div class="table-responsive">
              <table class="table table-striped">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Timestamp</th>
                  </tr>
                </thead>
                <tbody>
  <?php
      // Output data of each row
      while($row = $result->fetch_assoc()) {
  ?>
                  <tr>
                    <td><?php echo $row["customer_id"]; ?></td>
                    <td><?php echo $row["customer_name"]; ?></td>
                    <td><?php echo $row["customer_email"]; ?></td>
                    <td><?php echo $row["customer_timestamp"]; ?></td>
                  </tr>
  <?php
      }
  ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
  <?php
      }
    } else {
      echo "No customers found";
    }

  ?>

</div>
<script>
  document.getElementById('searchInput').addEventListener('input', function () {
    var searchInput = this.value.toUpperCase();
    var displayRows = document.querySelectorAll('.table-striped tbody tr');

    for (var i = 0; i < displayRows.length; i++) {
      var customerName = displayRows[i].getElementsByTagName('td')[1].textContent.toUpperCase();
      var displayStyle = customerName.indexOf(searchInput) > -1 ? '' : 'none';
      displayRows[i].style.display = displayStyle;
    }
  });
</script>
       <!-- JavaScript -->
    <script src="script.js"></script>
    
  </body>
</html>