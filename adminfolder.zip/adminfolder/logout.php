<?php
session_start();
session_unset();
echo "<script>alert('logged out');</script>";
header("location:../login-register.php");
?>