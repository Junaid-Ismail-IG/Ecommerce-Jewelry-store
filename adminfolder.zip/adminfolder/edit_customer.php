<?php
include('includes/dbconfig.php');
   

if (!$connect) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $customer_id = $_GET['id'];

    $query = "SELECT * FROM customers_detail WHERE customer_id = $customer_id";
    $result = mysqli_query($connect, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $customer = mysqli_fetch_assoc($result);
    } else {
        echo "Customer not found.";
        exit;
    }
} else {
    echo "Invalid customer ID.";
    exit;
}

// Process form submission if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and update customer details
    $first_name = mysqli_real_escape_string($connect, $_POST['first_name']);
    $last_name = mysqli_real_escape_string($connect, $_POST['last_name']);
    $email = mysqli_real_escape_string($connect, $_POST['email']);
    $country = mysqli_real_escape_string($connect, $_POST['country']);
    $street_address = mysqli_real_escape_string($connect, $_POST['street_address']);
    $town = mysqli_real_escape_string($connect, $_POST['town']);
    $state = mysqli_real_escape_string($connect, $_POST['state']);
    $postcode = mysqli_real_escape_string($connect, $_POST['postcode']);
    $phone = mysqli_real_escape_string($connect, $_POST['phone']);

    $updateQuery = "UPDATE customers_detail SET 
                    first_name = '$first_name', 
                    last_name = '$last_name', 
                    email = '$email', 
                    country = '$country', 
                    street_address = '$street_address', 
                    town = '$town', 
                    state = '$state', 
                    postcode = '$postcode', 
                    phone = '$phone' 
                    WHERE customer_id = $customer_id";

    $updateResult = mysqli_query($connect, $updateQuery);

    if ($updateResult) {
        // Redirect to the customer details page after updating
        header("Location: orders.php");
        exit;
    } else {
        echo "Error updating customer details.";
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Edit Customer</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>
    <div class="container mt-5">
        <h1 class="mb-4">Edit Customer</h1>
        
        <form method="post" action="">
            <div class="mb-3">
                <label for="first_name" class="form-label">First Name:</label>
                <input type="text" class="form-control" name="first_name" value="<?php echo $customer['first_name']; ?>" required>
            </div>

            <div class="mb-3">
                <label for="last_name" class="form-label">Last Name:</label>
                <input type="text" class="form-control" name="last_name" value="<?php echo $customer['last_name']; ?>" required>
            </div>

            <div class="mb-3">
                <label for="email" class="form-label">Email:</label>
                <input type="email" class="form-control" name="email" value="<?php echo $customer['email']; ?>" required>
            </div>

            <div class="mb-3">
                <label for="country" class="form-label">Country:</label>
                <input type="text" class="form-control" name="country" value="<?php echo $customer['country']; ?>" required>
            </div>

            <div class="mb-3">
                <label for="street_address" class="form-label">Street Address:</label>
                <input type="text" class="form-control" name="street_address" value="<?php echo $customer['street_address']; ?>" required>
            </div>

            <div class="mb-3">
                <label for="town" class="form-label">Town / City:</label>
                <input type="text" class="form-control" name="town" value="<?php echo $customer['town']; ?>" required>
            </div>

            <div class="mb-3">
                <label for="state" class="form-label">State / Division:</label>
                <input type="text" class="form-control" name="state" value="<?php echo $customer['state']; ?>" required>
            </div>

            <div class="mb-3">
                <label for="postcode" class="form-label">Postcode / ZIP:</label>
                <input type="text" class="form-control" name="postcode" value="<?php echo $customer['postcode']; ?>" required>
            </div>

            <div class="mb-3">
                <label for="phone" class="form-label">Phone:</label>
                <input type="tel" class="form-control" name="phone" value="<?php echo $customer['phone']; ?>" required>
            </div>

            <!-- Add more fields as needed -->

            <button type="submit" class="btn btn-primary">Update</button>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>
