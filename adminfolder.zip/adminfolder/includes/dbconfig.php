<?php
$connect = mysqli_connect("localhost", "root", "", "jewelry_store");

if (!$connect) {
    die("Connection failed: " . mysqli_connect_error());
}

?>
