<?php


if (isset($_POST["add_product"])) {
    $product_name = $_POST["product_name"];
    $product_description = $_POST["product_description"];
    $image = $_FILES["image"]["name"];
     $image_temp = $_FILES["image"]["tmp_name"];
    $image_path = "productimages/" . $image;

move_uploaded_file($image_temp, $image_path);

    $price = $_POST["price"];
    $category = $_POST["product_category"];
    $limited_description = substr($product_description, 0, 250);
    include('includes/dbconfig.php');
   
    $querry = "INSERT INTO products(`product_name`, `image_url`, `price`,`product_category`, `product_description`) VALUES ('$product_name','$image','$price','$category','$product_description')";
    $querry_run= mysqli_query($connect,$querry);    
    if ($querry_run) {
               echo"<div class='alert alert-success' role='alert'>
               Product added successfully!
             </div>";
               header('location:products.php');
               exit();
            } else {
                echo"<script>alert('someting else')</script>";
            }
        }
   
   
   
        if (isset($_GET["id"]) && isset($_GET["deleteproduct"])) {
            $id = $_GET["id"];
            $connect = mysqli_connect("localhost", "root", "", "jewelry_store");
        
            $delquery = "DELETE FROM products WHERE product_id = $id";
            $deletequeryrun = mysqli_query($connect, $delquery);
        
            if ($deletequeryrun) {
                echo"<div class='alert alert-success' role='alert'>
                Product added successfully!
              </div>";
                header('location:products.php');
                exit();
            } else {
                echo "<script>alert('Error deleting product: " . mysqli_error($connect) . "')</script>";
            }
        }

        
?>